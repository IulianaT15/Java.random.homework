
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scr = new Scanner(System.in);
        System.out.print("Введите ваше имя : ");
        String name = scr.nextLine();
        System.out.print("Введите ваш возраст : ");
        int age = scr.nextInt();
        System.out.print("Введите ваш вес : ");
        int weight = scr.nextInt();
        System.out.println("Уважаемый , " + name + "!" + " В свои " + age + " лет " + "," + " вы для нас дороги,как " + weight + " килограмм золота .");

    }
}