import java.util.Random;
import java.util.UUID;
import java.util.concurrent.ThreadLocalRandom;

public class Main {
    public static void main(String[] args) {
        Random rnd = new Random();
        int intValue = rnd.nextInt();
        System.out.println("Int Value is = " + intValue);
        float floatValue = rnd.nextFloat();
        System.out.println("Float Value is = " + floatValue);
        long longValue = rnd.nextLong();
        System.out.println("Long Value is = " + longValue);
        boolean booleanValue = rnd.nextBoolean();
        System.out.println("Boolean Value is = " + booleanValue);
        double doubleValue = rnd.nextDouble();
        System.out.println("Double Value is =" + doubleValue);

        String str = UUID.randomUUID().toString();
        System.out.println("String Value is = " + str);
    }
}