import java.util.Scanner;

public class Main {
    public static void main (String[ ] args) {
        Scanner scr = new Scanner(System.in);
        System.out.print(" Введите первое целое число : ");
        int n1 = scr.nextInt();
        System.out.print(" Введите второе целое число : ");
        int n2 = scr.nextInt();
        int sum = n1 + n2;
        System.out.println(" Сумма = "+sum );
        int sub = n1 - n2;
        System.out.println(" Вычитание = "+sub);
        int mult = n1 * n2;
        System.out.println(" Умножение = "+mult);
        int div = n1 / n2;
        System.out.println(" Деление = "+div);


    }
}